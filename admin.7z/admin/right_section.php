<?php
require '../components/prevention_admin.php';

?>
<div class="right-section">
    <div class="nav">
        <button id="menu-btn">
            <span class="material-icons-sharp">
                menu
            </span>
        </button>
        <div class="dark-mode" id="dark-mode-btn">
<span class="material-icons-sharp active" id="light-mode-icon">wb_sunny</span>
</div>


        <div class="profile">
            <div class="info">
                <p>Hey, <b>Bahaa</b></p>
                <small class="text-muted">Admin</small>
            </div>
            <!-- <div class="profile-photo">
                <img src="../images/pic-1.png">
            </div> -->
        </div>

    </div>
    <!-- End of Nav -->

    <div class="user-profile">
        <div class="logo">
            <img src="../images/pic-1.png">
            <h2>Bema mall</h2>
            
        </div>
        
    </div>
    <span style="color: red; font-weight: bold;">Be Very Carefull About Making Any Changes in Here Please!</span>

  

    </div>
    <script src="index.js"></script>