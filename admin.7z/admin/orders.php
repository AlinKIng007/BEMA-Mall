<?php


session_start();

require '../components/prevention_admin.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>bema dashboard</title>
    <style>
        table {
            width: 30%;
            min-width: 700px;
            max-width: 701px;
        }

        .order-owner {
            display: flex;
            align-items: center;
            text-transform: capitalize;
            font-weight: 500;
        }

        .order-owner img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            margin-right: 15px;
        }

        table thead tr {
            text-align: left;
        }

        table th,
        table td {
            padding: 20px 0;
            border-bottom: 1px solid var(--border-color);
        }

        .order-status {
            padding: 5px 15px;
            border-radius: 5px;
            font-weight: 500;
        }

        .order-processing {
            color: #2a59d1;
            background-color: rgba(62, 121, 247, 0.1);
        }

        .order-delivering {
            color: #ffc107;
            background-color: rgba(255, 193, 7, 0.1);
        }

        .order-completed {
            color: #4caf50;
            background-color: rgba(76, 175, 80, 0.1);
        }

        .order-refused {
            color: #e91e63;
            background-color: rgba(233, 30, 99, 0.1);
        }

        .order-failed {
            color: #f44336;
            background-color: rgba(244, 67, 54, 0.1);
        }

        .overflow-scroll {
            overflow-y: auto;
        }

        .overlay {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            display: none;
        }

        .overlay.active {
            display: block;
        }
    </style>
</head>

<body>

    <div class="container">
    <?php 
include 'aside.php';
?>

        <!-- Main Content -->
        <main>
            <h1>Orders</h1>
            <input type="text" id="searchInput" class="search-input" placeholder="Search by name">

            <!-- ORDERS TABLE -->
            <div class="box">
                <div class="box-body overflow-scroll">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Order status</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody id="orders-table-body">
                            <!-- Table rows will be dynamically added here -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="pagination">
                <!-- Pagination links will be dynamically added here -->
            </div>
            <!-- END ORDERS TABLE -->
        </main>
        <!-- End of Main Content -->

        <?php include 'right_section.php'; ?>
    </div>


    <script src="index.js"></script>
    <script>

// Function to fetch orders data from the server
async function fetchOrdersData() {
    try {
        const response = await fetch('orders_get.php'); // Path to your PHP script
        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }
        const orders = await response.json();
        return orders;
    } catch (error) {
        console.error('Error fetching data:', error);
        return []; // Return an empty array in case of an error
    }
}

// Function to populate the orders table with fetched data
async function populateOrdersTable() {
    const tbody = document.getElementById('orders-table-body');
    const orders = await fetchOrdersData();
    tbody.innerHTML = generateTableRows(orders);
}

// Initial page load
populateOrdersTable();


        // Function to generate pagination links
        function generatePaginationLinks(totalPages, currentPage) {
            let paginationLinks = '';
            for (let i = 1; i <= totalPages; i++) {
                paginationLinks += `<a href="#" class="${i === currentPage ? 'active' : ''}" onclick="navigateToPage(${i})">${i}</a>`;
            }
            return paginationLinks;
        }

        // Function to navigate to a specific page
        async function navigateToPage(pageNumber) {
            const pageSize = 10; // Number of orders per page
            const tbody = document.getElementById('orders-table-body');
            const pagination = document.querySelector('.pagination');

            const orders = await fetchOrdersData(pageNumber, pageSize);
            tbody.innerHTML = generateTableRows(orders);

            pagination.innerHTML = generatePaginationLinks(5, pageNumber); // Assuming 5 total pages

            // Add event listeners to pagination links
            const paginationLinks = document.querySelectorAll('.pagination a');
            paginationLinks.forEach(link => {
                link.addEventListener('click', function(event) {
                    event.preventDefault();
                    const pageNumber = parseInt(event.target.textContent);
                    navigateToPage(pageNumber);
                });
            });
        }

        // Initial page load
        navigateToPage(1);
    </script>
</body>

</html>
