<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <label>Write what you want to see</label>
    <textarea id="request" cols="30" rows="10"></textarea>
    <button id="submitBtn" type="button">Submit</button>
    <div id="result"></div>

    <script>
        $(document).ready(function() {
            $('#submitBtn').click(function() {
                var userInput = $('#request').val();
                $.ajax({
                    url: '/generate-sql',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({ "prompt": userInput , "type":"mysql","schema":""}),
                    success: function(response) {
                        $('#result').text("SQL Generated: " + response);
                    },
                    error: function(xhr, status, error) {
                        $('#result').text("Error generating SQL: " + error);
                    }
                });
            });
        });
    </script>
</body>
</html>
