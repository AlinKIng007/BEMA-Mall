<?php
require "../components/connect.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Include jQuery library -->
</head>

<body>
    <form id="selectForm" method="post">
        <label for="tableSelect">Select Table:</label>
        <select id="tableSelect" name="tableSelect">
            <?php
            try {
                $stmt = $conn->prepare("call GetTables(?)");
                $stmt->execute([$db_name]);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<option value='" . $row["table_name"] . "'>" . $row["table_name"] . "</option>";
                }
            } catch (PDOException $e) {
                echo "Connection failed: " . $e->getMessage();
            }
            ?>
        </select>

        <label>Select Columns:</label>
        <div id="columnSelect"></div> <!-- Column checkboxes will be populated here -->

        <label for="where">Enter WHERE condition:</label>
        <input type="text" id="where" name="where" placeholder="e.g., column_name = 'value'">

        <button type="submit">Submit</button>
    </form>

    <div id="result"></div>

    <script>
        $(document).ready(function() {
            // Function to fetch columns based on selected table
            $("#tableSelect").change(function() {
                var table = $(this).val();
                fetchColumns(table);
            });

            function fetchColumns(table) {
                $.ajax({
                    url: "fetch_column.php",
                    type: "POST",
                    data: {
                        table_name: table
                    },
                    success: function(data) {
                        $("#columnSelect").html(data);
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching table fields:", error);
                    }
                });
            }

            // Function to handle form submission
            $("#selectForm").submit(function(event) {
                event.preventDefault(); // Prevent default form submission

                var table = $("#tableSelect").val();
                var where = $("#where").val();
                var columns = [];
                $("input[name='columns']:checked").each(function() {
                    columns.push($(this).val());
                });

                $.ajax({
                    url: "fetch_data.php",
                    type: "POST",
                    data: {
                        table_name: table,
                        column_names: columns,
                        where: where
                    },
                    success: function(data) {
                        if (Array.isArray(data)) {
                            var resultHtml = "<table border='1'>";
                            var columns = Object.keys(data[0]);
                            resultHtml += "<tr>";
                            columns.forEach(function(column) {
                                resultHtml += "<th>" + column + "</th>";
                            });
                            resultHtml += "</tr>";
                            data.forEach(function(item) {
                                resultHtml += "<tr>";
                                columns.forEach(function(column) {
                                    resultHtml += "<td>" + item[column] + "</td>";
                                });
                                resultHtml += "</tr>";
                            });
                            resultHtml += "</table>";
                            $("#result").html(resultHtml);
                        } else {
                            console.error("Invalid data format received from server.");
                            
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching data:", error);
                    }
                });
            });
        });
    </script>

</body>

</html>
