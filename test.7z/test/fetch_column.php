<?php
require "../components/connect.php";

if (isset($_POST['table_name'])) {

    try {

        $tableName = $_POST['table_name'];

        $stmt = $conn->prepare("SHOW COLUMNS FROM $tableName");
        $stmt->execute();

        $checkboxes = "";
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $columnName = $row["Field"];
            $checkboxes .= "<input type='checkbox' name='columns' value='$columnName' id='$columnName'>";
            $checkboxes .= "<label for='$columnName'>$columnName</label><br>";
        }

        echo $checkboxes;
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null;
} else {
    echo "<p>Table not selected.</p>";
}
?>
