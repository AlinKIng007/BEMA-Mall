<?php
require "../components/connect.php";
$where = null;

if (isset($_POST['table_name']) && isset($_POST['column_names'])) {
    try {
        $tableName = $_POST['table_name'];
        $columnNames = $_POST['column_names'];

        // Validate column names to prevent SQL injection
        foreach ($columnNames as $columnName) {
            if (!preg_match('/^[a-zA-Z_]+$/', $columnName)) {
                throw new Exception('Invalid column name: ' . $columnName);
            }
        }

        // Construct the column names string for the SQL query
        $columnString = implode(', ', array_map(function($name) {
            return "`$name`";
        }, $columnNames));

        // Check if a WHERE clause is provided
        if(isset($_POST['where']) && trim($_POST['where']) !== '') {
            $where = "WHERE " . $_POST['where'];
        }

        // Adjust the SQL query to fetch data from the selected columns
        $sql = "SELECT $columnString FROM `$tableName` $where";
        $stmt = $conn->prepare($sql);

        // If a WHERE clause is provided, bind the parameters
        if(isset($_POST['where']) && trim($_POST['where']) !== '') {
            // Parse the WHERE clause to extract column name and value
            preg_match('/(\w+)\s*([=<>])\s*(\w+)/', $_POST['where'], $matches);
            $columnName = trim($matches[1]);
            $operator = trim($matches[2]);
            $value = trim($matches[3]);

            // Bind the parameter for the WHERE clause
            $bindValue = $value; // You might need to adjust this depending on your specific case
            $stmt->bindParam(':value', $bindValue);
        }

        $stmt->execute();

        // Fetch all rows of data
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if any data is returned
        if (count($data) > 0) {
            // Send the fetched data as JSON response
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
            // If no data is returned, send a message indicating so
            echo json_encode(array('message' => 'No data found for the selected columns.'));
        }
    } catch(PDOException $e) {
        // Handle any PDO exceptions
        echo json_encode(array('error' => 'Error: ' . $e->getMessage()));
    } catch(Exception $e) {
        // Handle any other exceptions
        echo json_encode(array('error' => 'Error: ' . $e->getMessage()));
    }

    $conn = null;
} else {
    // If table name or column names are not provided, send an error message
    echo json_encode(array('error' => 'Table or columns not selected.'));
}
?>
