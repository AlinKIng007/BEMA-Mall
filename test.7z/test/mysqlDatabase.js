const mysqlDatabase = `
        
-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS cart;
CREATE TABLE cart  (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NULL DEFAULT NULL,
  product_id int NULL DEFAULT NULL,
  amount int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX cart_product_id_foreign(product_id ASC) USING BTREE,
  INDEX cart_user_id_foreign(user_id ASC) USING BTREE,
  CONSTRAINT cart_product_id_foreign FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT cart_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 152 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS categories;
CREATE TABLE categories  (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  category_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX categories_category_id_foreign(category_id ASC) USING BTREE,
  CONSTRAINT categories_category_id_foreign FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for chats
-- ----------------------------
DROP TABLE IF EXISTS chats;
CREATE TABLE chats  (
  id int NOT NULL AUTO_INCREMENT,
  conversation_id int NULL DEFAULT NULL,
  message varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  opened_time datetime NULL DEFAULT NULL,
  sent_time datetime NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX chats_conversation_id_foreign(conversation_id ASC) USING BTREE,
  CONSTRAINT chats_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for conversations
-- ----------------------------
DROP TABLE IF EXISTS conversations;
CREATE TABLE conversations  (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for countries
-- ----------------------------
DROP TABLE IF EXISTS countries;
CREATE TABLE countries  (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  abv char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ISO 3166-1 alpha-2',
  abv3 char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'ISO 3166-1 alpha-3',
  abv3_alt char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  code varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'ISO 3166-1 numeric',
  slug varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 239 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for coupons
-- ----------------------------
DROP TABLE IF EXISTS coupons;
CREATE TABLE coupons  (
  id int NOT NULL AUTO_INCREMENT,
  discount varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  code varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  is_active int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for department_employee
-- ----------------------------
DROP TABLE IF EXISTS department_employee;
CREATE TABLE department_employee  (
  id int NOT NULL AUTO_INCREMENT,
  department_id int NULL DEFAULT NULL,
  employee_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX department_id_fk(department_id ASC) USING BTREE,
  INDEX employes_id_fk(employee_id ASC) USING BTREE,
  CONSTRAINT department_id_fk FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT employes_id_fk FOREIGN KEY (employee_id) REFERENCES employees (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for departments
-- ----------------------------
DROP TABLE IF EXISTS departments;
CREATE TABLE departments  (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  mall_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX mall_id_fk(mall_id ASC) USING BTREE,
  CONSTRAINT mall_id_fk FOREIGN KEY (mall_id) REFERENCES malls (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for employees
-- ----------------------------
DROP TABLE IF EXISTS employees;
CREATE TABLE employees  (
  id int NOT NULL AUTO_INCREMENT,
  gender varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  hire_date date NULL DEFAULT NULL,
  salary decimal(20, 2) NULL DEFAULT NULL,
  user_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX user_id_fk(user_id ASC) USING BTREE,
  CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for event_type
-- ----------------------------
DROP TABLE IF EXISTS event_type;
CREATE TABLE event_type  (
  id int NOT NULL AUTO_INCREMENT,
  type varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for events
-- ----------------------------
DROP TABLE IF EXISTS events;
CREATE TABLE events  (
  id int NOT NULL AUTO_INCREMENT,
  event_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  start_time datetime NULL DEFAULT NULL,
  mall_id int NULL DEFAULT NULL,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  image varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  end_time datetime NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX events_mall_id_foreign(mall_id ASC) USING BTREE,
  CONSTRAINT events_mall_id_foreign FOREIGN KEY (mall_id) REFERENCES malls (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for floors
-- ----------------------------
DROP TABLE IF EXISTS floors;
CREATE TABLE floors  (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  mall_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX floors_mall_id_foreign(mall_id ASC) USING BTREE,
  CONSTRAINT floors_mall_id_foreign FOREIGN KEY (mall_id) REFERENCES malls (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for group_members
-- ----------------------------
DROP TABLE IF EXISTS group_members;
CREATE TABLE group_members  (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NULL DEFAULT NULL,
  conversation_id int NULL DEFAULT NULL,
  joined_time datetime NULL DEFAULT NULL,
  left_time datetime NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX group_members_conversation_id_foreign(conversation_id ASC) USING BTREE,
  INDEX group_members_user_id_foreign(user_id ASC) USING BTREE,
  CONSTRAINT group_members_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT group_members_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for main_products
-- ----------------------------
DROP TABLE IF EXISTS main_products;
CREATE TABLE main_products  (
  id int NOT NULL AUTO_INCREMENT,
  sku varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  product_weight_in_grams double NULL DEFAULT NULL COMMENT 'weight in grams example (product_weight = 2300 grams)',
  product_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  category_id int NULL DEFAULT NULL,
  image_1 varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  image_2 varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  image_3 varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  production_date date NULL DEFAULT NULL,
  expiration_date date NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  UNIQUE INDEX product_name(product_name ASC) USING BTREE,
  INDEX main_products_category_id_foreign(category_id ASC) USING BTREE,
  CONSTRAINT main_products_category_id_foreign FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 330 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for malls
-- ----------------------------
DROP TABLE IF EXISTS malls;
CREATE TABLE malls  (
  id int NOT NULL AUTO_INCREMENT,
  mall_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  mall_address varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  has_3d tinyint NULL DEFAULT NULL,
  has_2d tinyint NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 54 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for offer_configurations
-- ----------------------------
DROP TABLE IF EXISTS offer_configurations;
CREATE TABLE offer_configurations  (
  id int NOT NULL AUTO_INCREMENT,
  offer_id int NULL DEFAULT NULL,
  category_id int NULL DEFAULT NULL,
  product_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX offer_configurations_category_id_foreign(category_id ASC) USING BTREE,
  INDEX offer_configurations_offer_id_foreign(offer_id ASC) USING BTREE,
  INDEX offer_configurations_product_id_foreign(product_id ASC) USING BTREE,
  CONSTRAINT offer_configurations_category_id_foreign FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT offer_configurations_offer_id_foreign FOREIGN KEY (offer_id) REFERENCES offers (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT offer_configurations_product_id_foreign FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for offers
-- ----------------------------
DROP TABLE IF EXISTS offers;
CREATE TABLE offers  (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  discount_rate int NULL DEFAULT NULL,
  start_date date NULL DEFAULT NULL,
  end_date datetime NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS orders;
CREATE TABLE orders  (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NULL DEFAULT NULL,
  amount int NULL DEFAULT NULL,
  time_of_purchase datetime NULL DEFAULT NULL,
  status_id int NULL DEFAULT NULL,
  payment_method_id int NULL DEFAULT NULL,
  product_id int NULL DEFAULT NULL,
  employee_id int NULL DEFAULT NULL,
  coupon_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX orders_payment_method_id_foreign(payment_method_id ASC) USING BTREE,
  INDEX orders_product_id_foreign(product_id ASC) USING BTREE,
  INDEX orders_status_id_foreign(status_id ASC) USING BTREE,
  INDEX orders_user_id_foreign(user_id ASC) USING BTREE,
  INDEX orders_employee_id_fk(employee_id ASC) USING BTREE,
  INDEX orders_coupons_id_fk(coupon_id ASC) USING BTREE,
  CONSTRAINT orders_coupons_id_fk FOREIGN KEY (coupon_id) REFERENCES coupons (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT orders_employee_id_fk FOREIGN KEY (employee_id) REFERENCES employees (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT orders_payment_method_id_foreign FOREIGN KEY (payment_method_id) REFERENCES payment_method (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT orders_product_id_foreign FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT orders_status_id_foreign FOREIGN KEY (status_id) REFERENCES status (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT orders_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 361 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for payment_method
-- ----------------------------
DROP TABLE IF EXISTS payment_method;
CREATE TABLE payment_method  (
  id int NOT NULL AUTO_INCREMENT,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  method_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  face_to_face int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for positions
-- ----------------------------
DROP TABLE IF EXISTS positions;
CREATE TABLE positions  (
  id int NOT NULL AUTO_INCREMENT,
  shelf_id int NULL DEFAULT NULL,
  x int NULL DEFAULT NULL COMMENT 'north',
  z int NULL DEFAULT NULL COMMENT 'east',
  PRIMARY KEY (id) USING BTREE,
  INDEX positions_shelf_id_foreign(shelf_id ASC) USING BTREE,
  CONSTRAINT positions_shelf_id_foreign FOREIGN KEY (shelf_id) REFERENCES shelves (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for product_config
-- ----------------------------
DROP TABLE IF EXISTS product_config;
CREATE TABLE product_config  (
  id int NOT NULL AUTO_INCREMENT,
  product_id int NULL DEFAULT NULL,
  variation_option_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX product_config_variation_option_id_foreign(variation_option_id ASC) USING BTREE,
  INDEX product_config_product_id_foreign(product_id ASC) USING BTREE,
  CONSTRAINT product_config_ibfk_1 FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT product_config_ibfk_2 FOREIGN KEY (variation_option_id) REFERENCES variation_option (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS products;
CREATE TABLE products  (
  id int NOT NULL AUTO_INCREMENT,
  main_product_id int NULL DEFAULT NULL,
  sku varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  amount int NULL DEFAULT NULL,
  price int NULL DEFAULT NULL,
  offer_id int NULL DEFAULT NULL,
  position_id int NULL DEFAULT NULL,
  is_published bit(1) NULL DEFAULT NULL,
  shipment_id int NULL DEFAULT NULL,
  date_added datetime NULL DEFAULT NULL,
  barcode varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX products_main_product_id_foreign(main_product_id ASC) USING BTREE,
  INDEX products_position_id_foreign(position_id ASC) USING BTREE,
  INDEX products_shipment_id_foreign(shipment_id ASC) USING BTREE,
  CONSTRAINT products_main_product_id_foreign FOREIGN KEY (main_product_id) REFERENCES main_products (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT products_position_id_foreign FOREIGN KEY (position_id) REFERENCES positions (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT products_shipment_id_foreign FOREIGN KEY (shipment_id) REFERENCES shipments (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 259 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS roles;
CREATE TABLE roles  (
  id int NOT NULL AUTO_INCREMENT,
  title_id int NULL DEFAULT NULL,
  employee_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX employee_id_fk(employee_id ASC) USING BTREE,
  INDEX title_id_fk(title_id ASC) USING BTREE,
  CONSTRAINT employee_id_fk FOREIGN KEY (employee_id) REFERENCES employees (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT title_id_fk FOREIGN KEY (title_id) REFERENCES titles (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for shelf_types
-- ----------------------------
DROP TABLE IF EXISTS shelf_types;
CREATE TABLE shelf_types  (
  id int NOT NULL AUTO_INCREMENT,
  type varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  compartments int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for shelves
-- ----------------------------
DROP TABLE IF EXISTS shelves;
CREATE TABLE shelves  (
  id int NOT NULL AUTO_INCREMENT,
  shop_id int NULL DEFAULT NULL,
  shelf_type_id int NULL DEFAULT NULL,
  from_north float NULL DEFAULT NULL,
  to_north float NULL DEFAULT NULL,
  from_east float NULL DEFAULT NULL,
  to_east float NULL DEFAULT NULL,
  height int NULL DEFAULT NULL,
  width int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX shelves_shelf_type_id_foreign(shelf_type_id ASC) USING BTREE,
  INDEX shelves_shop_id_foreign(shop_id ASC) USING BTREE,
  CONSTRAINT shelves_shelf_type_id_foreign FOREIGN KEY (shelf_type_id) REFERENCES shelf_types (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT shelves_shop_id_foreign FOREIGN KEY (shop_id) REFERENCES shops (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for shipments
-- ----------------------------
DROP TABLE IF EXISTS shipments;
CREATE TABLE shipments  (
  id int NOT NULL AUTO_INCREMENT,
  supplier_id int NULL DEFAULT NULL,
  requested_on_time datetime NULL DEFAULT NULL,
  expected_arrival_time datetime NULL DEFAULT NULL,
  each_price int NULL DEFAULT NULL,
  amount int NULL DEFAULT NULL,
  pending tinyint(1) NULL DEFAULT NULL,
  processing tinyint(1) NULL DEFAULT NULL,
  cancelled tinyint(1) NULL DEFAULT NULL,
  delivered tinyint(1) NULL DEFAULT NULL,
  actual_arrival_time datetime NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX shipments_supplier_id_foreign(supplier_id ASC) USING BTREE,
  CONSTRAINT shipments_supplier_id_foreign FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for shop_coupon
-- ----------------------------
DROP TABLE IF EXISTS shop_coupon;
CREATE TABLE shop_coupon  (
  id int NOT NULL AUTO_INCREMENT,
  shop_id int NULL DEFAULT NULL,
  coupon_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX coupon_id_fk(coupon_id ASC) USING BTREE,
  INDEX shop_id_fk(shop_id ASC) USING BTREE,
  CONSTRAINT coupon_id_fk FOREIGN KEY (coupon_id) REFERENCES coupons (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT shop_id_fk FOREIGN KEY (shop_id) REFERENCES shops (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for shops
-- ----------------------------
DROP TABLE IF EXISTS shops;
CREATE TABLE shops  (
  id int NOT NULL AUTO_INCREMENT,
  shop_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  monthly_rent int NULL DEFAULT NULL,
  monthly_ad int NULL DEFAULT NULL,
  floor_id int NULL DEFAULT NULL,
  north_in_meters int NULL DEFAULT NULL,
  east_in_meters int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX shops_floor_id_foreign(floor_id ASC) USING BTREE,
  CONSTRAINT shops_floor_id_foreign FOREIGN KEY (floor_id) REFERENCES floors (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for status
-- ----------------------------
DROP TABLE IF EXISTS status;
CREATE TABLE status  (
  id int NOT NULL AUTO_INCREMENT,
  type varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  level int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for suppliers
-- ----------------------------
DROP TABLE IF EXISTS suppliers;
CREATE TABLE suppliers  (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  address varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  email varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  phone_number varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for tickets
-- ----------------------------
DROP TABLE IF EXISTS tickets;
CREATE TABLE tickets  (
  id int NOT NULL AUTO_INCREMENT,
  title varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  subject varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  time_of_submission datetime NULL DEFAULT NULL,
  user_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX user_id_tickets_fk(user_id ASC) USING BTREE,
  CONSTRAINT user_id_tickets_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for titles
-- ----------------------------
DROP TABLE IF EXISTS titles;
CREATE TABLE titles  (
  id int NOT NULL,
  title varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  description varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  allowance int NULL DEFAULT 0,
  PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for user_shop
-- ----------------------------
DROP TABLE IF EXISTS user_shop;
CREATE TABLE user_shop  (
  id int NOT NULL AUTO_INCREMENT,
  shop_id int NULL DEFAULT NULL,
  user_id int NULL DEFAULT NULL,
  time_of_acquisition datetime NULL DEFAULT NULL,
  start_date date NULL DEFAULT NULL,
  end_date datetime NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX user_shop_shop_id_foreign(shop_id ASC) USING BTREE,
  INDEX user_shop_user_id_foreign(user_id ASC) USING BTREE,
  CONSTRAINT user_shop_shop_id_foreign FOREIGN KEY (shop_id) REFERENCES shops (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT user_shop_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users  (
  id int NOT NULL AUTO_INCREMENT,
  username varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  hash varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  salt varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  display_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  first_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  last_name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  address varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  p_p varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  last_seen timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  email varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  phone_number varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  city varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  zip_code int NULL DEFAULT NULL,
  country_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX country_id_fk(country_id ASC) USING BTREE,
  CONSTRAINT country_id_fk FOREIGN KEY (country_id) REFERENCES countries (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for variation
-- ----------------------------
DROP TABLE IF EXISTS variation;
CREATE TABLE variation  (
  id int NOT NULL AUTO_INCREMENT,
  category_id int NULL DEFAULT NULL,
  name varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX variation_category_id_foreign(category_id ASC) USING BTREE,
  CONSTRAINT variation_category_id_foreign FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for variation_option
-- ----------------------------
DROP TABLE IF EXISTS variation_option;
CREATE TABLE variation_option  (
  id int NOT NULL AUTO_INCREMENT,
  variation_id int NULL DEFAULT NULL,
  value varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX variation_option_variation_id_foreign(variation_id ASC) USING BTREE,
  CONSTRAINT variation_option_variation_id_foreign FOREIGN KEY (variation_id) REFERENCES variation (id) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for wishlist
-- ----------------------------
DROP TABLE IF EXISTS wishlist;
CREATE TABLE wishlist  (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NULL DEFAULT NULL,
  product_id int NULL DEFAULT NULL,
  PRIMARY KEY (id) USING BTREE,
  INDEX wishlist_product_id_foreign(product_id ASC) USING BTREE,
  INDEX wishlist_user_id_foreign(user_id ASC) USING BTREE,
  CONSTRAINT wishlist_product_id_foreign FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT wishlist_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

`;